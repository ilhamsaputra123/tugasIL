package com.example.tugasIL

sealed class screens (val Screen:String){
    data object Screen1 : screens("Screen 1")
    data object Screen2 : screens("Screen 2")
    data object Screen3 : screens("Screen 3")

}