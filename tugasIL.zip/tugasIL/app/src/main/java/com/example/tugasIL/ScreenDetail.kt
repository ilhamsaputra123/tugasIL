package com.example.tugasIL

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Column
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.TopAppBar
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppBarWithBackButton(
    title: String,
    onBackPressed: () -> Unit
) {
    TopAppBar(
        title = { Text(title) },
        navigationIcon = {
            IconButton(onClick = onBackPressed) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back"
                )
            }
        }
    )
}

@Composable
fun ScreenDetail(fruitName: String, onBackPressed: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color.White
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 16.dp),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AppBarWithBackButton(title = "Detail", onBackPressed = onBackPressed)
            Image(
                painter = painterResource(id = getImageResourceId(fruitName)),
                contentDescription = "Foto $fruitName",
                modifier = Modifier.size(200.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(text = fruitName)
            Spacer(modifier = Modifier.height(8.dp))
            Description(fruitName = fruitName)
        }
    }
}

@Composable
fun Description(fruitName: String) {
    val description = when (fruitName) {
        "Apel" -> "Apel mengandung banyak mineral penting, termasuk zat besi dan kalium. Keduanya menawarkan manfaat untuk meningkatkan kekuatan dan kepadatan tulang."
        "Jeruk" -> "Jeruk merupakan sebuah buah yang memiliki khasiat. Jeruk yang merupakan buah sitrus memiliki banyak kandungan vitamin C dan anti oksidan, yang meningkatkan sistem kekebalan tubuh dan membantu melawan infeksi dan flu."
        "Pisang" -> "Pisang kaya akan potasium, mineral yang penting bagi penjagaan fungsi jantung dan sirkulasi darah."
        "Anggur" -> "Buah anggur mengandung antioksidan yang tinggi, sehingga mampu membantu tubuh dalam menurunkan tekanan darah tinggi."
        "Strawberry" -> "Strawberry terkenal akan manfaatnya untuk mengurangi peradangan dalam tubuh. Hal ini termasuk pada pengidap radang sendi atau arthritis. Mengonsumsi buah yang memiliki sifat anti peradangan, seperti strawberry, bisa meredakan gejala arthritis yang mengganggu."
        "Melon" -> "Buah melon tidak hanya memberikan rasa kenyang, tetapi juga membantu melancarkan pencernaan. Nutrisi ini bekerja secara efektif dalam menjaga kesehatan saluran pencernaan, mencegah masalah sembelit, dan mendukung fungsi usus yang optimal."
        "Nanas" -> "Buah nanas memiliki kandungan Enzim bromelain yang dapat membantu meningkatkan daya tahan tubuh, dan membantu mengurangi risiko kanker."
        "Mangga" -> "Mangga mengandung enzim yang dapat membantu melancarkan proses pencernaan."
        "Lemon" -> "Lemon kaya akan asam sitrat, vitamin C, asam folat, vitamin B5, B3, B1, B2, dan vitamin E. Nutrisi ini bertanggung jawab atas beberapa manfaat kesehatan."
        "Alpukat" -> "Alpukat memang merupakan salah satu makanan tinggi serat dan kalium yang dapat mengoptimalkan fungsi pencernaan."
        "Brokoli" -> "Brokoli kaya akan serat dan antioksidan. Keduanya dapat mendukung fungsi usus yang sehat dan kesehatan pencernaan."
        "Sayur Kol" -> "Kol memiliki kandungan antioksidan alami, terutama antosianin, yang membantu melawan peradangan. Khasiat ini dapat melindungi sel-sel tubuh dari radikal bebas yang berbahaya, membantu mencegah penyakit seperti jantung, kanker, dan rheumatoid arthritis."
        "Sayur Bayam" -> "Bayam mengandung vitamin K, sehingga memiliki potensi untuk menjaga kesehatan tulang. Vitamin K berperan penting dalam sejumlah fungsi tubuh."
        "sayur Sawi" -> "Dengan mengonsumsi sayuran sawi, dapat membantu merangsang sistem kekebalan tubuh, mencegah stres oksidatif, dan menginduksi enzim detoksifikasi."
        "Sayur Kangkung" -> "Kangkung kaya akan kandungan beta karoten yang tinggi, sehingga baik dalam menjaga sel-sel mata dari kerusakan."
        "Seledri" -> "Selain untuk mengontrol gula darah, daun seledri juga cocok dipakai untuk mengatasi masalah kolesterol."
        "Wortel" -> "Wortel dapat menjaga kesehatan mata. Sayuran ini juga sangat baik untuk kesehatan mata."
        "Tomat" -> "Tomat merupakan buah yang mengandung vitamin C dan antioksidan. Kandungan yang terdapat dalam buah tomat memberikan manfaat dalam melawan pembentukan radikal bebas penyebab kanker."
        "Timun" -> "Manfaat timun dapat membantu melindungi tubuh dari kanker."
        "Pare" -> "Tidak hanya cocok jadi menu diet atau mengurangi risiko terkena kanker, pare juga dapat membantu meredakan asma, menurunkan kolestrol, meningkatkan imun tubuh, meningkatkan penglihatan, dan menjaga kesehatan tulang."
        "Pisang Goreng" -> "Pisang goreng merupakan salah satu cemilan favorit di Asia Tenggara. Potongan pisang dengan balutan tepung yang renyah dan manis, membuat banyak orang ketagihan."
        "Tempe Goreng" -> "Tempe adalah makanan khas Indonesia yang terbuat dari fermentasi kedelai atau beberapa bahan lain yang menggunakan beberapa jenis kapang Rhizopus"
        "Tahu Goreng" -> "Konsumsi tahu goreng memiliki banyak manfaat kesehatan, antara lain dapat menurunkan kadar kolesterol, mencegah penyakit jantung, menjaga kesehatan tulang, mencegah kanker, dan membantu menurunkan berat badan."
        "Risol" -> "Risoles, atau biasa disebut risol, adalah pastri berisi daging, biasanya daging cincang, dan sayuran yang dibungkus dadar, dan digoreng setelah dilapisi tepung panir dan kocokan telur ayam.   "
        "Pempek" -> "Pempek adalah salah satu makanan tradisional asal Palembang provinsi Sumatera Selatan. Makanan ini terbuat dari bahan dasar sagu dan ikan"
        "Piscok" -> "Piscok adalah salah satu varian camilan yang terkenal dan banyak disukai oleh masyarakat Indonesia. Piscok sendiri merupakan singkatan dari pisang cokelat."
        "Bakwan" -> "Bakwan merupakan makanan gorengan yang terbuat dari sayuran dan tepung terigu yang lazim ditemukan di Indonesia."
        "Martabak Mie" -> "Martabak mi adalah hidangan martabak dari mi yang dicampur dengan telur dan digoreng dengan minyak goreng atau mentega. Martabak mi merupakan hidangan dari Indonesia."
        "Martabak Telur" -> " Martabak telur merupakan panganan dengan rasa gurih. Sayur, daging, dan berbagai bumbu lainnya digabung menjadi satu dalam sebuah kulit adonan"
        "Cimol" -> "Cimol adalah makanan ringan khas Sunda yang dibuat dari tepung kanji. Cimol berasal dari kata aci digemol yang artinya tepung kanji dibentuk bulat-bulat sehingga tekstur Cimol kenyal."
        else -> ""
    }

    Text(
        text = description,
        fontSize = 16.sp,
        textAlign = TextAlign.Center,
        modifier = Modifier.fillMaxWidth()
    )
}

fun getImageResourceId(fruitName: String): Int {
    return when (fruitName) {
        "Apel" -> R.drawable.apel
        "Jeruk" -> R.drawable.jeruk
        "Pisang" -> R.drawable.pisang
        "Anggur" -> R.drawable.anggur
        "Strawberry" -> R.drawable.stroberi
        "Melon" -> R.drawable.melon
        "Nanas" -> R.drawable.nanas
        "Mangga" -> R.drawable.mangga
        "Lemon" -> R.drawable.lemon
        "Alpukat" -> R.drawable.alpukat
        "Brokoli" -> R.drawable.brokoli
        "Sayur Kol" -> R.drawable.kol
        "Sayur Bayam" -> R.drawable.bayam
        "sayur Sawi" -> R.drawable.sawi
        "Sayur Kangkung" -> R.drawable.kangkung
        "Seledri" -> R.drawable.seledri
        "Wortel" -> R.drawable.wortel
        "Tomat" -> R.drawable.tomat
        "Timun" -> R.drawable.timun
        "Pare" -> R.drawable.pare
        "Pisang Goreng" -> R.drawable.pisang_goreng
        "Tempe Goreng" -> R.drawable.tempe_goreng
        "Tahu Goreng" -> R.drawable.tahu_goreng
        "Risol" -> R.drawable.risol
        "Pempek" -> R.drawable.pempek
        "Piscok" -> R.drawable.piscok
        "Bakwan" -> R.drawable.bakwan
        "Martabak Mie" -> R.drawable.martabak_mie
        "Martabak Telur" -> R.drawable.martabak_telur
        "Cimol" -> R.drawable.cimol
        else -> R.drawable.ic_launcher_background
    }
}
