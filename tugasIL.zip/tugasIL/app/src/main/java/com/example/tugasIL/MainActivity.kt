package com.example.tugasIL

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.tugasIL.ui.theme.AplikasibuahTheme
import com.example.tugasIL.ui.theme.red

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AplikasibuahTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MyBottomAppBar()
                }
            }
        }
    }
}

@Composable
fun MyBottomAppBar(){
    val navController = rememberNavController()
    val selected = remember {
        mutableStateOf(Icons.Default.Home)
    }

    Scaffold (
        bottomBar = {
            BottomAppBar(
                containerColor = red
            ) {
                IconButton(
                    onClick = {
                        selected.value = Icons.Default.List
                        navController.navigate(screens.Screen1.Screen){
                            popUpTo(0)
                        }
                    },
                    modifier = Modifier.weight(1f)){
                    Icon(Icons.Default.List , contentDescription = null, modifier = Modifier.size(26.dp),
                        tint = if (selected.value == Icons.Default.List) Color.White else Color.DarkGray)
                }
                IconButton(
                    onClick = {
                        selected.value = Icons.Default.List
                        navController.navigate(screens.Screen2.Screen){
                            popUpTo(0)
                        }
                    },
                    modifier = Modifier.weight(1f)){
                    Icon(Icons.Default.List , contentDescription = null, modifier = Modifier.size(26.dp),
                        tint = if (selected.value == Icons.Default.List) Color.White else Color.DarkGray)
                }
                IconButton(
                    onClick = {
                        selected.value = Icons.Default.AccountBox
                        navController.navigate(screens.Screen3.Screen){
                            popUpTo(0)
                        }
                    },
                    modifier = Modifier.weight(1f)){
                    Icon(Icons.Default.AccountBox , contentDescription = null, modifier = Modifier.size(26.dp),
                        tint = if (selected.value == Icons.Default.AccountBox) Color.White else Color.DarkGray)
                }
            }
        }
    ){ paddingValues ->
        NavHost(
            navController = navController,
            startDestination = screens.Screen1.Screen,
            modifier = Modifier.padding(paddingValues)
        ) {
            composable(screens.Screen1.Screen) {
                Screen1(navController = navController) { item ->
                    navController.navigate("ScreenDetail/$item")
                }
            }

            composable(screens.Screen2.Screen) {
                Screen2(navController = navController)
            }
            composable(screens.Screen3.Screen) { Screen3() }

            composable("ScreenDetail/{fruitName}") { backStackEntry ->
                val fruitName = backStackEntry.arguments?.getString("fruitName") ?: ""
                ScreenDetail(fruitName = fruitName) {
                    navController.popBackStack()
                }
            }

        }
    }
}

@Preview
@Composable
fun MyBottomBarPreview(){
    AplikasibuahTheme {
        MyBottomAppBar()
    }
}
