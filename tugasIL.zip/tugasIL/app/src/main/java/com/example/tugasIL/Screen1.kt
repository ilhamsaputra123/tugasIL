package com.example.tugasIL

import android.annotation.SuppressLint
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController

val fruits = listOf(
    "Apel", "Jeruk", "Pisang", "Anggur", "Strawberry",
    "Melon", "Nanas", "Mangga", "Lemon", "Alpukat"
)

val vegetables = listOf(
    "Brokoli", "Sayur Kol", "Sayur Bayam", "sayur Sawi", "Sayur Kangkung",
    "Seledri", "Wortel", "Tomat", "Timun", "Pare"
)

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun Screen1(navController: NavHostController, onItemClick: (String) -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(text = "Screen 1 Lazy Row dan Lazy Column")
                }
            )
        },
        content = {
            Column {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 15.dp, vertical = 47.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    items(fruits.size) { index ->
                        val fruitName = fruits[index]
                        PhotoItemRow(fruitName) {
                            onItemClick(fruitName)
                        }
                    }
                }
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 15.dp, vertical = 15.dp)
                ) {
                    items(vegetables.size) { index ->
                        val vegetablesName = vegetables[index]
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            PhotoItemColumn(vegetablesName) {
                                onItemClick(vegetablesName)
                            }
                        }
                    }
                }
            }
        }
    )
}

@Composable
fun PhotoItemRow(photoName: String, onClick: () -> Unit) {
    val imageResId = when (photoName) {
        "Apel" -> R.drawable.apel
        "Jeruk" -> R.drawable.jeruk
        "Pisang" -> R.drawable.pisang
        "Anggur" -> R.drawable.anggur
        "Strawberry" -> R.drawable.stroberi
        "Melon" -> R.drawable.melon
        "Nanas" -> R.drawable.nanas
        "Mangga" -> R.drawable.mangga
        "Lemon" -> R.drawable.lemon
        "Alpukat" -> R.drawable.alpukat
        else -> R.drawable.ic_launcher_background
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(horizontal = 10.dp)
    ) {
        androidx.compose.foundation.Image(
            painter = painterResource(id = imageResId),
            contentDescription = "Foto $photoName",
            modifier = Modifier.size(250.dp)
                .clickable(onClick = onClick)
        )
        Text(
            text = photoName,
            fontSize = 20.sp,
            modifier = Modifier.padding(top = 1.dp),
            style = androidx.compose.ui.text.TextStyle.Default,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}

@Composable
fun PhotoItemColumn(photoName: String, onClick: () -> Unit) {
    val imageResId = when (photoName) {
        "Brokoli" -> R.drawable.brokoli
        "Sayur Kol" -> R.drawable.kol
        "Sayur Bayam" -> R.drawable.bayam
        "sayur Sawi" -> R.drawable.sawi
        "Sayur Kangkung" -> R.drawable.kangkung
        "Seledri" -> R.drawable.seledri
        "Wortel" -> R.drawable.wortel
        "Tomat" -> R.drawable.tomat
        "Timun" -> R.drawable.timun
        "Pare" -> R.drawable.pare
        else -> R.drawable.ic_launcher_background
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(horizontal = 10.dp)
    ) {
        androidx.compose.foundation.Image(
            painter = painterResource(id = imageResId),
            contentDescription = "Foto $photoName",
            modifier = Modifier.size(150.dp)
                .clickable(onClick = onClick)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = photoName,
            fontSize = 17.sp,
            style = androidx.compose.ui.text.TextStyle.Default,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}

