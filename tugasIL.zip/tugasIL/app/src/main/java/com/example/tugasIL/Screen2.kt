package com.example.tugasIL

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.NavHostController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Screen2(navController: NavHostController) {
    val imageList = listOf(
        "Pisang Goreng", "Tempe Goreng", "Tahu Goreng", "Risol", "Pempek",
        "Piscok", "Bakwan", "Martabak Mie", "Martabak Telur", "Cimol"
    )

    Box(modifier = Modifier.fillMaxSize()) {
        Column {
            TopAppBar(
                title = { Text(text = "Screen 2 Lazy Grid") },
            )
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.fillMaxSize()
            ) {
                items(imageList) { imageName ->
                    GridItem(imageName, navController)
                }
            }
        }
    }
}

@Composable
fun getFruitImageResourceId(fruitName: String): Int {
    return when (fruitName) {
        "Pisang Goreng" -> R.drawable.pisang_goreng
        "Tempe Goreng" -> R.drawable.tempe_goreng
        "Tahu Goreng" -> R.drawable.tahu_goreng
        "Risol" -> R.drawable.risol
        "Pempek" -> R.drawable.pempek
        "Piscok" -> R.drawable.piscok
        "Bakwan" -> R.drawable.bakwan
        "Martabak Mie" -> R.drawable.martabak_mie
        "Martabak Telur" -> R.drawable.martabak_telur
        "Cimol" -> R.drawable.cimol
        else -> R.drawable.ic_launcher_background
    }
}
@Composable
fun GridItem(imageName: String, navController: NavController) {
    Box(
        modifier = Modifier
            .size(100.dp)
            .padding(8.dp)
            .background(Color.LightGray)
            .clickable {
                navController.navigate("ScreenDetail/$imageName")
            },
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = getFruitImageResourceId(imageName)),
            contentDescription = null,
            modifier = Modifier.fillMaxSize()
        )
    }
}

